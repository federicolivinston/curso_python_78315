from setuptools import setup

setup(
    name="work_pakage",
    version="0.1.0",
    description="acciones del flujo y gestion de base de datos.",
    author="Federico Livingston",
    author_email="federico_livingston@hotmail.com",
    packages=[
        "work_package",
    ],
)
